#!/usr/bin/env bash

_build/default/test/public.exe



